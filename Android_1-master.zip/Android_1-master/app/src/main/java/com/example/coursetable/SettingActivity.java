package com.example.coursetable;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;
import java.util.ArrayList;
//目前想的是一进来就打开Syllabus，所以目前主活动是它，往后可能会改

public class SettingActivity extends AppCompatActivity {

    private RelativeLayout day;
    private DrawerLayout mDrawerLayout;
    //创建数据库（只在程序安装的时候加载）
    private DatabaseHelper databaseHelper = new DatabaseHelper(this, "database.db", null, 1);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        //加载顶部菜单栏（别的活动可能也需要）
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //抽屉布局
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle;
        toggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView naviView = (NavigationView) findViewById(R.id.nav_view);
//        setContentView(R.layout.activity_main);

        //navi栏的默认选择
        naviView.setCheckedItem(R.id.nav_setting);
        //对navi栏进行事件监听

        //你们的活动加载写在这个函数里面
        naviView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if(id == R.id.nav_syllabus){
                    Intent intent = new Intent( SettingActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }else if(id == R.id.nav_reminder){
                    //你们的Activity
                    Toast.makeText( SettingActivity.this, "Here is Syllabus", Toast.LENGTH_SHORT).show();
                }else if(id == R.id.nav_calender) {
                    //你们的Activity
                    Toast.makeText( SettingActivity.this, "Here is Calender", Toast.LENGTH_SHORT).show();
                } else if(id == R.id.nav_setting) {
                    mDrawerLayout.closeDrawer(GravityCompat.START);
                }
                return true;
            }
        });
        Button logout = (Button)findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
